require 'rubygems'
require 'daemons'

Daemons.run('graphital.rb')
